Unzip the files at the same directory with submission.py
Run the following to test the submission.
$ python testing.py

Example output:
01_test.txt 0.026 seconds
02_test.txt 0.002 seconds
03_test.txt 0.025 seconds
04_test.txt 0.000 seconds
05_test.txt 0.001 seconds
06_test.txt 0.040 seconds
07_test.txt 0.093 seconds
08_test.txt 0.241 seconds
09_test.txt 0.452 seconds
10_test.txt 4.373 seconds
11_test.txt 18.20 seconds
12_test.txt 74.39 seconds
In total, 12/12 tests are correct.